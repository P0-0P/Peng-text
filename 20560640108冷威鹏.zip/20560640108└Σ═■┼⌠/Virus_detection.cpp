#include<iostream>
#include<cstring>
#define MAXLEN 100
using namespace std;
//���崮�Ľṹ��
typedef struct {
    char ch[MAXLEN];
    int length = 0;
}SString;
//���Ӻ���(��������ַ���ת������,���Ҵ�1��ʼ�洢)
void add(SString& S, string Z) {
    for (int i = 1;i <= Z.length();i++) {
        S.ch[i] = Z[i-1];
    }
    S.length = Z.length();
}
//BF�㷨
void BF(SString Z, SString M) {
    int i = 1, j = 1;
    while (i <= Z.length && j <= M.length) {
        if (Z.ch[i] == M.ch[j]) {
            ++i;
            ++j;
        }
        else {
            i = i - j + 2;
            j = 1;
        } 
    }
    if (j > M.length)
        cout<< "YES";
    else
        cout<< "NO"; 
}
//KMP�㷨
void KMP(SString Z, SString M, int next[]) {
    int i = 1, j = 1;
    while (i <= Z.length && j <= M.length) {
         if (Z.ch[i] == M.ch[j]) {
            ++i;
            ++j;
         }
         else {
             j = next[j];
         }
    }
    if (j > M.length)
        cout<< "YES";
    else
        cout<< "NO"; 
}
//next����
void getNext(SString M, int next[]) {
    next[1] = 0;
    int i = 1, j = 0;
    while (i <= M.length) {
        if (j == 0 || M.ch[i] == M.ch[j])
            next[++i] =++j;
        else
            j = next[j];
    }
}
int main() {
    string Zstring;
    string Mstring;
    int next[20];
    SString Z, M;
    cout << "������������"<<endl;
    cin >> Zstring;
    cout << "������ģ�崮��"<<endl;
    cin >> Mstring;
    add(Z, Zstring);
    add(M, Mstring);
    getNext(M, next);
    //BF(Z, M);
    KMP(Z, M, next);
}
    


